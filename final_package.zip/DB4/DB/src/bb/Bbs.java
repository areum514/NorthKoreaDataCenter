package bb;

public class Bbs {

		private int idpost;
		private String title;
		
		private String date;
		
		private String writer;
		private String contents;
		private int views;
		private int num_comments;
		private int type;
		public int getIdpost() {
			return idpost;
		}
		public void setIdpost(int idpost) {
			this.idpost = idpost;
		}
		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}
		public String getDate() {
			return date;
		}
		public void setDate(String date) {
			this.date = date;
		}
		public String getWriter() {
			return writer;
		}
		public void setWriter(String writer) {
			this.writer = writer;
		}
		public String getContents() {
			return contents;
		}
		public void setContents(String contents) {
			this.contents = contents;
		}
		public int getViews() {
			return views;
		}
		public void setViews(int views) {
			this.views = views;
		}
		public int getNum_comments() {
			return num_comments;
		}
		public void setNum_comments(int num_comments) {
			this.num_comments = num_comments;
		}
		public int getType() {
			return type;
		}
		public void setType(int type) {
			this.type = type;
		}
		

}
