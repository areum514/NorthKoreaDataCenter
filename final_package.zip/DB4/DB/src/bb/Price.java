package bb;

public class Price {

	private int idprice;
	private int price;
	private int	year;
	
	private int avg_year;
	private int avg_price;
	
	private int max_year;
	private int min_year;
	
	private int max_price;
	private int min_price;
	
	public int getIdprice() {
		return idprice;
	}
	public void setIdprice(int idprice) {
		this.idprice = idprice;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	
	
	public int getAvgYear() {
		return avg_year;
	}
	public void setAvgYear(int avg_year) {
		this.avg_year = avg_year;
	}
	public int getAvgPrice() {
		return avg_price;
	}
	public void setAvgPrice(int avg_price) {
		this.avg_price = avg_price;
	}
	
	
	
	public int getMax_year() {
		return max_year;
	}
	public void setMax_year(int max_year) {
		this.max_year = max_year;
	}
	public int getMin_year() {
		return min_year;
	}
	public void setMin_year(int min_year) {
		this.min_year = min_year;
	}
	public int getMax_price() {
		return max_price;
	}
	public void setMax_price(int max_price) {
		this.max_price = max_price;
	}
	public int getMin_price() {
		return min_price;
	}
	public void setMin_price(int min_price) {
		this.min_price = min_price;
	}
	
	

}
